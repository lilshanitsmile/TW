/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wt;

import java.util.ArrayList;
import java.util.List;


public class WT {

    
    public static void main(String[] args) {
        
        
        List<Chicos> listachicos = new ArrayList<>();
    Chicos juan =new Chicos("juan","masculino","pistear");
     Chicos pedro =new Chicos("pedro","masculino","");
      Chicos luis =new Chicos("luis","masculino","bailar");
       Chicos mateo =new Chicos("mateo","masculino","bailar");
        Chicos ana =new Chicos("ana","femennino","bailar");
         Chicos maria =new Chicos("maria","femenino","pistear");
          Chicos wicho =new Chicos("wicho","femenino","pistear");
    
          
          listachicos.add(juan);
           listachicos.add(pedro);
            listachicos.add(luis);
             listachicos.add(mateo);
              listachicos.add(ana);
               listachicos.add(maria);
                listachicos.add(wicho);
                
                
                for (Chicos lista:listachicos){
                    if (lista.gusto.equals("bailar")&& lista.sexo.equals("masculino")) {
                        System.out.println("A maria le gustan...."+ lista.nombre + " por que es de sexo.."+ lista.sexo + " y por que le encanta" + lista.gusto);
                    }
                }
        
    }
    
        
}
